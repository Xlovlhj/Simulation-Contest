"""数值计算入口。AI辅助程序编写；工具记录见AI工具使用详情.pdf。"""
from pathlib import Path
import argparse,sys,subprocess,shutil,tempfile,json
ROOT=Path(__file__).resolve().parent
if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8')
sys.path.insert(0,str(ROOT/'src'))
import reproduce

def compute(command):
    runs=ROOT/'reproduced';runs.mkdir(exist_ok=True)
    target=Path(tempfile.mkdtemp(prefix=command+'_',dir=runs))
    shutil.copytree(ROOT,target,dirs_exist_ok=True,ignore=shutil.ignore_patterns('reproduced','__pycache__','*.pyc','.git'))
    if command=='all':
        code="import sys;sys.path.insert(0,'src');from bev.workflow import run_all;run_all()"
        cmd=[sys.executable,'-X','utf8','-u','-c',code]
    else:
        cmd=[sys.executable,'-X','utf8','-u','scripts/review_revision_checks.py']
    subprocess.run(cmd,cwd=target,check=True)
    metrics=reproduce.check_results(target) if command=='all' else {}
    report={'command':command,'exit_code':0,'work_directory':target.relative_to(ROOT).as_posix(),
            'metrics_checked':metrics,'full_refit_repeated':False,
            'note':'all复用已保存的参数、控制、长程及重采样结果；supplement重新计算本轮新增对照。'}
    (ROOT/('REPRODUCTION_'+command+'.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))

def main():
    p=argparse.ArgumentParser(description='C题：文件校验、准备数据与数值复现')
    p.add_argument('command',choices=['verify','prepare','all','supplement','long','refit'])
    p.add_argument('--official-data',help='已解压的完整官方赛题目录')
    a=p.parse_args()
    if a.command=='verify':reproduce.verify();return
    reproduce.prepare(a.official_data)
    if a.command=='prepare':return
    if a.command in ['all','supplement']:compute(a.command)
    else:reproduce.isolated_run(a.command)

if __name__=='__main__':main()
