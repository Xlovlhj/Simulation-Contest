"""从修订源模板生成论文和真实AI补充记录；不修改原科学冻结文件。"""
from pathlib import Path
import ast, json, re, sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from bev.io import read_json,sha256
from bev.paper import collect_content,verify_evidence
from bev.remediation_report import paper_fragments
from bev.extension_report import paper_fragments as extension_fragments
from bev.documents import make_html,render_pdf

template=ROOT/'paper/final.template.md'
original=ROOT/'paper/final.before_review_20261019.md'
if not original.exists():original.write_bytes(template.read_bytes())
text=original.read_text(encoding='utf-8')
head,body=text.split('<!-- PAPER_ABSTRACT_END -->',1)
head='''# 电动车能量流与热管理的集中参数仿真、校准和约束节能控制

## 摘要

电动车的驱动、电池损耗与温控用电相互耦合，仅比较驾驶结束时的电耗可能把遗留热量误计为节能。建立纵向动力学、双向机电转换、内阻等效电池及电池—座舱双热节点的集中参数模型，以电池端净电能统一计量。25℃公开CLTC-P复现序列下，参考模型百公里电耗为@@BASE_CONSUMPTION@@ kWh/100 km，完成七参数双幅度灵敏度分析。

仅用575、596两条路程联合估计空气阻力、滚动阻力、内阻及共享干扰参数。588路程能耗误差由@@VAL_ENERGY_BEFORE@@%降至@@VAL_ENERGY_AFTER@@%，SOC均方根误差由@@VAL_SOC_BEFORE@@降至@@VAL_SOC_AFTER@@个百分点；主非线性重拟合中@@CR_BOUND_PCT@@%的滚阻估计贴下界，参数尚不能解释为已准确辨识的实车真值。一阶RC仅作补充电压预测改进，第六章控制仍采用校准Rint内核。

以回收、冷却及座舱温控为决策量，离线比较72组反馈规则，在线每5秒更新。为检查延后温控造成的表观收益，统一初态并将90分钟驾驶和两小时共同带电停车温控合并核算；25、40、−10℃模型内总账节能率分别为@@REC_25@@%、@@REC_40@@%、@@REC_COLD@@%。另增加双方座舱目标同为24℃的对照，区分回收/冷却设置与温度目标变化的影响。

上述收益受模型、舒适服务及终态条件限制；测温与热失配下的严格终温仍存在失败，低温保守核算无稳定正收益。训练SOC覆盖不足且缺少本车热实测，长程结果涉及外推，不能据此承诺实车节能或温控精度。

**关键词：** 集中参数模型；参数校准；反馈控制；能量流；终态核算

'''
text=head+'<!-- PAPER_ABSTRACT_END -->'+body
text=text.replace('三个问题的原主实验共用同一物理内核。问题一核查机理和收支，问题二以数据约束该内核，问题三在暂定校准模型内比较策略。另在第5.6节隔离比较并推荐RC电压候选，不将旧控制结果冒充RC结果。控制结果不能反过来证明校准参数真实；热状态没有实测时，温控结果须保持仿真属性。',
'''三个问题按“机理基准—数据校准—控制比较”连接。问题一使用参考Rint模型，问题二校准其参数，问题三在校准Rint内核中比较策略。第5.6节的一阶RC是独立的电压结构改进，尚未接入第六章控制。本文主贡献是将驾驶与后续共同停车温控纳入统一能量账，检查收益是否来自未恢复的热状态；控制收益不反向证明参数真实。''')
text=text.replace('@@EXTERNAL_RC_CORRECTION@@','''@@EXTERNAL_RC_CORRECTION@@

### 5.7 最终采用模型与证据归属

| 模型及参数 | 本文用途 | 已支持的结果 | 主要边界 |
|---|---|---|---|
| 参考Rint | 问题一 | CLTC基准、七参数敏感性、守恒检查 | 参考参数，未完成实车全面标定 |
| 校准Rint | 问题二主分析、问题三主控制 | 参数对照、SOC/能耗评价、控制与停车总账 | 电压迁移和低SOC不足，热参数未实测 |
| 一阶RC候选 | 补充电压预测 | 588/600回顾电压误差改善 | 未重做控制、长程及参数区间 |

本稿采用校准Rint作为节能控制结论的计算内核，RC只用于电压补充比较。两者不合并为同一套已验证系统性能。''')
text=text.replace('有效容量不是铭牌实测，OCV常偏移也没有证明可跨SOC迁移。',
'''表6的三个指定参数使用第5.1节的单位和搜索范围。Cr估计接近0.003下界；在当前数据与模型下，求解器仍希望把滚阻调得更小，可能存在激励不足、参数补偿或结构误差，不能只归因于一种原因。SOC或能耗变好不等于每个参数已经估准。有效容量不是铭牌实测，OCV常偏移也没有证明可跨SOC迁移。''')
text=text.replace('### 6.2 可执行反馈规则与最优性边界', '''名义寻优保持式(11)全部约束；第6.5—6.7节另对测温误差和热失配做压力测试。后续将真实24±0.1℃改作探索条件时，仍单列原严格条件的失败率，不用放宽后的可行率替代原约束通过率。共同舒适温区允许温度轨迹不同，不能解释为完全同等舒适。

### 6.2 可执行反馈规则与最优性边界''')
text=text.replace('### 6.4 连续驾驶与实际停车恢复总账','''### 6.3.1 相同座舱目标的补充对照

为区分温度目标改变与其他控制设置的影响，修订中保持原模型、参数、初态、工况及全部约束，将冻结优化规则的座舱节能偏移单独置零，使双方全程目标均为24℃，回收及冷却设置不变。该对照不重新寻优、不使用新实测数据，属于看过既有结果后的补充诊断。以下均采用相同理想终态修正口径：

@@SAME_TARGET_TABLE@@

@@SAME_TARGET_INTERPRETATION@@

### 6.4 连续驾驶与实际停车恢复总账''')
start=text.index('## 7 结论、优势与局限')
end=text.index('## 8 参考文献与AI辅助说明')
text=text[:start]+'''## 7 结论、优势与局限

本文以共享机电热方程连接能耗、SOC及温度，分层核算避免重复计损。数据校准改善了指定路程的能耗与SOC预测，但滚阻贴边和电压外推失败表明，预测误差改善与物理参数可靠辨识应分别评价。校准Rint承担主要控制结论；一阶RC只承担补充电压预测结论。

控制贡献在于同时报告驾驶电耗、舒适偏差、终态热差及共同停车温控总账，避免把延后制冷直接计为节能。有限72组规则搜索只保证候选集合内最优；在线反馈依赖当前状态和计划到达时间。新增同24℃座舱目标对照用于识别温度目标取舍，不能替代真实舒适性试验。

最终可推荐的是指定参数与声明服务条件下的模型内控制比较。共同到达前冷却修正了已知高温热未对齐案例，但测温和热失配下仍有严格终温失败；不得概括为三温度均稳健节能。训练SOC范围窄，长程有大量低SOC外推；外部路阻和小电芯试用未解决本车参数、热精度、传感器误差、充电电流边界或未知到达时间问题。后续需要同车独立数据和硬件约束验证。

'''+text[end:]
text=text.replace('2026-10-17至2026-10-18；版本发布日期','2026-10-17至2026-10-19；版本发布日期')
text=text.replace('| PACKAGE_MANIFEST.json、EXPECTED_RESULTS.json | 逐文件校验值与关键结果核对基准 |',
'''| PACKAGE_MANIFEST.json、EXPECTED_RESULTS.json | 交接原包核对基准；修订文件另见REVISION_MANIFEST.json |
| scripts/review_revision_checks.py、records/revision_20261019/ | 新增同目标对照、长程正向重算及轨迹核算协议与记录 |''')
text+='''

## 附录B 源程序

以下按源文件路径列出共享物理模型、参数求解、控制和长程核算源程序。完整可运行工程及依赖同时置于支撑材料；程序检查和工具重算不等于实车有效性或队员独立工作。

@@SOURCE_APPENDIX@@
'''
# Once revised, the editable source is authoritative; future builds preserve manual edits.
if '### 5.7 最终采用模型与证据归属' in template.read_text(encoding='utf-8'):
    text=template.read_text(encoding='utf-8')
else:
    template.write_text(text,encoding='utf-8')
result=read_json(ROOT/'records/revision_20261019/results.json')
rows=[]
for r in result['same_target']:
    m=r['metrics']; s=r['same_target_accounting']['heat_corrected_saving_pct']; sel=r['selected_accounting']['heat_corrected_saving_pct']
    rows.append(f"| {r['ambient_c']:g}℃ | {m['baseline']['energy_kwh']:.6f} | {m['same_target']['energy_kwh']:.6f} | {s:.3f} | {sel:.3f} | {'满足' if m['same_target']['feasible'] else '不满足'} |")
same='| 环境 | 基准电能/kWh | 同目标候选电能/kWh | 同目标热修正节能/% | 原联合热修正节能/% | 同目标候选约束 |\n|---|---|---|---|---|---|\n'+'\n'.join(rows)
interpret='同目标对照保留回收和冷却设置，因此其收益不能全部归因于回收；与原联合结果的差别也包含机电热耦合，不宜作严格可加分解。低温回收受保护限幅，温度目标变化的贡献须单列。'
sources=[]
for name in ['src/bev/model.py','src/bev/calibration.py','src/bev/control.py','src/bev/durability.py','src/bev/voltage_rc.py','scripts/review_revision_checks.py']:
    content=(ROOT/name).read_text(encoding='utf-8')
    sources.append('### '+name+'\n\n```python\n'+content.rstrip()+'\n```')
fingerprint=verify_evidence()
tokens,ledger=collect_content()
tokens['SERIES_CELLS']=str(read_json(ROOT/'data/processed/component_curves.json')['series_cells'])
tokens.update(paper_fragments());tokens.update(extension_fragments())
tokens.update(SAME_TARGET_TABLE=same,SAME_TARGET_INTERPRETATION=interpret,SOURCE_APPENDIX='\n\n'.join(sources))
for k,v in tokens.items():text=text.replace('@@'+k+'@@',v)
assert not re.search(r'@@[A-Z_0-9]+@@',text)
source=ROOT/'docs/论文/C题论文_修订稿.md'
source.write_text(text,encoding='utf-8')
dest=ROOT/'交付材料/修订稿'
dest.mkdir(parents=True,exist_ok=True)
html=dest/'C题论文_修订稿.html';pdf=dest/'C题论文_修订稿.pdf'
make_html(text,source,html,title='C题论文修订稿',paper=True)
# Source appendix is technical material; keep body typography unchanged and print code legibly.
markup=html.read_text(encoding='utf-8').replace('</style>', '''
pre {white-space:pre-wrap; overflow-wrap:anywhere; word-break:break-all; font-family:Consolas,'Microsoft YaHei',monospace; font-size:8pt; line-height:1.25; margin:2mm 0 4mm;}
pre code {font-size:8pt; line-height:1.25;}
main > h2[id="b"] {break-before:page;}
.contents-page li {margin:0 0 .25mm;line-height:1;}
table:has(th:nth-child(6)) td:first-child {white-space:nowrap;}
</style>''')
html.write_text(markup,encoding='utf-8')
paper=render_pdf(html,pdf,paper=True)
if '--paper-only' in sys.argv:
    oldbuild=read_json(ROOT/'records/revision_20261019/build.json')
    oldbuild['paper']=paper
    oldbuild['editorial_cleanup']='Sentence-function audit: enumerated deletions, no new experiment or changed result'
    (ROOT/'records/revision_20261019/build.json').write_text(json.dumps(oldbuild,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'paper':paper},ensure_ascii=False,indent=2))
    raise SystemExit(0)
ai=ROOT/'docs/AI工具使用详情.md'
aitext=ai.read_text(encoding='utf-8')
aihtml=dest/'AI工具使用详情_修订工作稿.html';aipdf=dest/'AI工具使用详情_修订工作稿.pdf'
make_html(aitext,ai,aihtml,title='AI工具使用详情（修订工作稿）')
aireport=render_pdf(aihtml,aipdf)
build={'paper':paper,'ai_disclosure':aireport,'scope':'Editorial revision and stated retrospective computations; team review remains pending.',
       'frozen_scientific_inputs_unchanged':True,'source_appendix_files':[s.splitlines()[0][4:] for s in sources],
       'source_hashes':fingerprint,'review_results_sha256':sha256(ROOT/'records/revision_20261019/results.json')}
(ROOT/'records/revision_20261019/build.json').write_text(json.dumps(build,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'paper':paper,'ai':aireport},ensure_ascii=False,indent=2))
