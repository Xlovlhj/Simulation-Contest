"""Delete enumerated non-argumentative sentences/clauses; no euphemistic replacements."""
from pathlib import Path
import hashlib,json,re,shutil
ROOT=Path(__file__).resolve().parents[1]
BACKUP=ROOT.parent/'删冗前备份'
BACKUP.mkdir(exist_ok=True)
entries=[]

template_deletions=[
('，不能据此承诺实车节能或温控精度','已有SOC覆盖与实测缺口说明，尾句重复一般性警告'),
('；控制收益不反向证明参数真实','未讨论以控制收益证明参数，属于提前回应未提出的质疑'),
('，不能据此重新宣称600为未见盲测','前文已明确600为回顾检验，重复辩护'),
('，不认定哪一项是笔误','已交代容量冲突及两种处理方案，未推进分析'),
('训练得到的有效容量也不等同铭牌容量。','有效容量定义和容量冲突在后文已有具体说明，此处重复'),
('，两者不混用','前文已分别定义拟合与报告口径，属于操作训诫'),
('，不是组委会给定的额定标定','工程比较设定的来源已明确，无需回应官方认证问题'),
('，不使用同一个效率简单反乘','双向转换步骤已完整给出，尾句重复反面提醒'),
('，不能截断牵引后继续声称完成原车速任务','牵引超限报错已定义模型行为，尾句为额外辩护'),
('25℃电池没有触发冷却，不意味着其他温度下冷却总是无影响。','跨温度结果另有实验，本句仅阻止假想过度解释'),
('将端能耗零响应写成“内阻不重要”会混淆指标。','前句已解释内阻对SOC、热量和端负载的不同作用'),
('，不是证明30 kWh与160 Ah可以混用','前半句已给出容量对照机制，尾句为假想误读辩护'),
('解析和守恒检查验证计算自洽，不替代实车验证。','没有新增计算结果，重复全篇的一般性边界警告'),
('，保留历史，不把改进目标的过程隐去','前文已交代v1失败和v2调整原因，自证透明不推进方法'),
('，不能只归因于一种原因','前句已列出多种机制，尾句重复'),
('SOC或能耗变好不等于每个参数已经估准。','贴边与参数补偿已有具体证据，本句重复概括性警告'),
('不能把全部改善归功于Cd、Cr、Rref。','前句已给出干扰参数对照的具体研究发现'),
('；不能只从SOC曲线判断电池模型有效','图和后续表已并列电压结果，尾句重复指令'),
('；低能耗误差不能掩盖电压失败，600仍只是回顾检验','电压恶化已报告，600角色前文已界定'),
('，并无有限样本或跨车辆覆盖证明','条件区间的模型、输入和残差假设已明确，此处泛化辩护重复'),
('，不能将全程总误差随意放在一个中点','前文已写明总能量行的分配方法，无需反面操作提醒'),
('，不能证明全局最优','该处报告多初值代价差，没有提出全局最优命题'),
('只有两条训练路程，重复计算并没有提供300个独立车辆样本。','数据路程数与重拟合次数已分别交代，重复反驳假想误解'),
('，不能简单称缺少高速','已给出最高车速和高速时段比例，本句只回应不存在的措辞'),
('剖面代价没有直接换算为卡方置信区间。','本文已给出实际区间构造，未作卡方区间声称'),
('局部满秩、重拟合相关或数值成功都不足以证明现实参数精度；','后半句给出具体误差来源，前半句是重复性辩护'),
('该联系通过共享内核实现，同时保留校准局限，未以黑箱模型替换物理状态，也不把模拟控制收益当作新的实测标定依据。','前一句已说明实测—校准—控制链条，本句重复自我辩护'),
('两者不合并为同一套已验证系统性能。','紧前模型归属表和采用说明已充分区分两者'),
('本节结论均限定在指定仿真内。','模型、参数和工况随后明确，空泛范围重复'),
('，未作为官方认证边界','约束来源已写明，论文没有提出官方认证'),
('，不用放宽后的可行率替代原约束通过率','前半句已要求单列严格条件，尾句重复反面辩护'),
('共同舒适温区允许温度轨迹不同，不能解释为完全同等舒适。','第6.3节有舒适偏差的具体数值与解释，避免在方法段提前重复'),
('，未证明连续决策或所有状态下全局最优，也未实现MPC','候选集合内最优已明确，未提出连续全局最优或MPC声称'),
('；不构成车载最坏执行时间认证','本机P95计时没有提出硬件认证声称'),
('，不能将问题一不同初值和参考参数结果当作控制基准','两章初值、参数及本节基准已明确，重复防误读'),
('，不能把所有温控节能称为“同等舒适”','前文及表13已提供舒适差异，尾句重复'),
('，不能全部解释成余热收益消失','前半句已解释补冷与分母变化，尾句重复'),
('，保留为未对齐，不用它证明公平热终态节能','超过比较门槛的数值已明确，重复声明如何不使用结果'),
('，数学可运行不证明低SOC电压或实车续航准确','前半句已量化SOC外推，尾句为一般性警告'),
('这是本控制器的条件关系，不是任何观测器都不能估计偏差的证明。','公式前已给出适用条件，未提出对所有观测器的不可能性命题'),
('，不能据此承诺0.1℃真实精度','本句已给出余量与误差预算缺口，尾句重复'),
('程序检查通过与实验约束通过分别统计，不将30/42改称全部通过，也不以数值收敛代替真实有效性。','程序检查与实验可行率已各自报告，本句为审查式训诫'),
('，不能替代真实舒适性试验','同目标对照的变量控制作用已明确，未提出人体试验声称'),
('最终可推荐的是指定参数与声明服务条件下的模型内控制比较。','重复全篇实验范围，没有新增结论'),
('；不得概括为三温度均稳健节能','前半句已指出失配下失败，尾句重复训诫'),
]
remediation_deletions=[
('，也未解决训练SOC覆盖不足','覆盖不足已在数据和局限集中交代'),
('，不能将改变边界解释为恢复参数可靠性','已有贴界和非物理解的实际结果，尾句重复'),
('，失败保留','失败数量已报告，自证保留不推进发现'),
('观测器改善模型内控制，仍非真实传感器校准或0.1℃实车保证。','紧前报告精确模型与失配通过率，重复一般性警告'),
('原失败是已知设计案例，修正结果不构成独立实测验证。','修正是针对已知失败的设计已经明示，未提出独立实测声称'),
]
extension_deletions=[
('，也不称滚阻可靠性已解决','拟合目标恶化和不采用外车参数已给出实际结论'),
('，不把拟合值称真实参数','两个参数贴边已报告，重复参数真实性警告'),
('，不把旧热控制结果写成RC模型结果','模型归属表已明确旧控制内核，尾句重复'),
('，不声称鲁棒认证','报告具体舒适失败即可，没有提出认证命题'),
]
def edit(relative,pairs,kind='template'):
    path=ROOT/relative
    backup=BACKUP/relative
    if backup.exists():raise RuntimeError('Refusing to overwrite backup '+str(backup))
    backup.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,backup)
    before=path.read_text(encoding='utf-8')
    if kind=='template':
        chunk,suffix=before.split('## 8 参考文献与AI辅助说明',1)
        prefix='';suffix='## 8 参考文献与AI辅助说明'+suffix
    else:
        prefix,chunk=before.split('def paper_fragments():',1)
        prefix+='def paper_fragments():'
        marker="if __name__=='__main__':publish()" if kind=='remediation' else '\ndef publish():'
        chunk,suffix=chunk.split(marker,1);suffix=marker+suffix
    for needle,reason in pairs:
        count=chunk.count(needle)
        if count!=1:raise RuntimeError(f'Expected one match, got {count}: {needle}')
        entries.append({'source':relative,'deleted':needle,'reason':reason,'operation':'delete_without_rephrasing'})
        chunk=chunk.replace(needle,'')
    chunk=re.sub(r'\n{3,}','\n\n',chunk)
    after=prefix+chunk+suffix
    path.write_text(after,encoding='utf-8')
    return {'path':relative,'before_sha256':hashlib.sha256(before.encode()).hexdigest(),'after_sha256':hashlib.sha256(after.encode()).hexdigest(),'characters_removed':len(before)-len(after)}
changes=[edit('paper/final.template.md',template_deletions),edit('src/bev/remediation_report.py',remediation_deletions,'remediation'),edit('src/bev/extension_report.py',extension_deletions,'extension')]
# The supplementary interpretation is authored in the build script.
build=ROOT/'scripts/build_review_revision.py';backup=BACKUP/'scripts/build_review_revision.py';backup.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(build,backup)
content=build.read_text(encoding='utf-8')
for needle,reason in [('；各温度的正负收益和可行状态均保留','表15已展示全部温度结果，不需要自证完整呈现')]:
    assert content.count(needle)==1
    content=content.replace(needle,'')
    entries.append({'source':'scripts/build_review_revision.py','deleted':needle,'reason':reason,'operation':'delete_without_rephrasing'})
content=content.replace("paper=render_pdf(html,pdf,paper=True)",'''paper=render_pdf(html,pdf,paper=True)
if '--paper-only' in sys.argv:
    oldbuild=read_json(ROOT/'records/revision_20261019/build.json')
    oldbuild['paper']=paper
    oldbuild['editorial_cleanup']='Sentence-function audit: enumerated deletions, no new experiment or changed result'
    (ROOT/'records/revision_20261019/build.json').write_text(json.dumps(oldbuild,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'paper':paper},ensure_ascii=False,indent=2))
    raise SystemExit(0)''')
build.write_text(content,encoding='utf-8')
pdf=ROOT/'交付材料/修订稿/C题论文_修订稿.pdf'
shutil.copy2(pdf,BACKUP/'C题论文_删冗前.pdf')
record={'scope':'Abstract and sections 1-7 plus generated paper paragraphs. Required disclosure, references, appendices, equations, tables, numerical results and scientific code unchanged.','deleted_units':len(entries),'entries':entries,'changes':changes}
dest=ROOT/'records/editorial_cleanup_20261019';dest.mkdir(exist_ok=True)
(dest/'deletions.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
report='# 正文逐句删冗记录\n\n按论证功能逐句审阅摘要及第1—7章。下表仅记录被直接删除的句子或分句；没有把这些文字换成委婉表达。方程、数值、实验条件、实际失败与参数辨识解释保留。\n\n'
report+='|序号|直接删除的原文|删除理由|\n|---|---|---|\n'
for i,row in enumerate(entries,1):report+=f"|{i}|{row['deleted'].replace('|','/')}|{row['reason']}|\n"
(ROOT.parent/'正文删冗记录.md').write_text(report,encoding='utf-8')
print(json.dumps({'deleted_sentences_or_clauses':len(entries),'template_deleted_units':len(template_deletions),'backup':str(BACKUP)},ensure_ascii=False,indent=2))
