from pathlib import Path
import json,sys
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
read=lambda name:json.loads((ROOT/name).read_text(encoding='utf-8'))
r=read('records/revision_20261019/results.json')
nominal=read('results/tables/control_evaluation.json')['nominal']
long=read('results/tables/durability_evaluation.json')['comparisons']
checks=[]
def check(label,actual,expected,tol=1e-9):
    passed=abs(actual-expected)<=tol
    checks.append({'label':label,'actual':actual,'expected':expected,'absolute_tolerance':tol,'passed':passed})
    assert passed,label
for row in r['same_target']:
    for name,old in [('baseline','baseline'),('selected','optimized')]:
        stored=next(x for x in nominal if x['strategy']==old and x['ambient_c']==row['ambient_c'])
        check(f"{row['ambient_c']}C {name} energy",row['metrics'][name]['energy_kwh'],stored['energy_kwh'])
for row in r['long_recomputed']:
    stored=next(x for x in long if x['parameter_set']=='calibrated_v2_provisional' and x['repetitions']==3 and x['parking_s']==7200 and x['ambient_c']==row['ambient_c'])
    check(f"{row['ambient_c']}C long saving",row['comparison']['raw_saving_pct'],stored['raw_saving_pct'])
for row in r['rc_forward']:
    stored=pd.read_csv(ROOT/f"records/experiments/extension_v1/rc_trip_{row['trip']}_predictions.csv")
    for name,column in [('soc','predicted_soc'),('voltage_v','predicted_voltage_v')]:
        delta=float(np.max(np.abs(np.array(row['prediction'][name])-stored[column].to_numpy())))
        check(f"RC {row['trip']} {name} max delta",delta,0.,1e-9)
    rmse=float(np.sqrt(np.mean((np.array(row['prediction']['voltage_v'])-stored.measured_voltage_v.to_numpy())**2)))
    print('RC',row['trip'],'voltage RMSE',rmse)
result={'numerical_checks':len(checks),'all_passed':all(c['passed'] for c in checks),'checks':checks,'note':'Frozen-parameter forward reruns and numerical checks only, no new independent real-world validation.'}
(ROOT/'records/revision_20261019/numerical_checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'numerical_checks':len(checks),'all_passed':result['all_passed']},ensure_ascii=False))
