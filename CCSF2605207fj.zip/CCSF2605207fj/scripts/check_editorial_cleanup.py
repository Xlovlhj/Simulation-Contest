from pathlib import Path
import hashlib,json,re
ROOT=Path(__file__).resolve().parents[1]
dest=ROOT/'records/editorial_cleanup_20261019'
p=dest/'deletions.json';d=json.loads(p.read_text(encoding='utf-8'))
extra=[
('paper/final.template.md','；缺少额定充电电流，不能声称已完成全部硬件认证','未提出全部硬件认证声称，缺失边界在局限中已有说明'),
('src/bev/extension_report.py','，也不将其包装为本车热精度验证','数据对象与基线对照已清楚，自证不包装没有论证功能'),
('src/bev/extension_report.py','保留失败、','列举控制方案时夹入自证完整性的措辞'),
('src/bev/extension_report.py','，不是实际硬件能耗上界','该量已定义为理想修正，正文没有提出硬件上界命题')]
for source,deleted,reason in extra:
    if not any(r['deleted']==deleted for r in d['entries']):d['entries'].append({'source':source,'deleted':deleted,'reason':reason,'operation':'delete_without_rephrasing'})
d['deleted_units']=len(d['entries']);p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
report='# 正文逐句删冗记录\n\n按论证功能审阅摘要及第1—7章；下表记录直接删除的句子或分句，未作委婉改写。方程、表格、实验数据、明确条件和失败发现保留。\n\n|序号|直接删除的原文|删除理由|\n|---|---|---|\n'
for i,row in enumerate(d['entries'],1):report+=f"|{i}|{row['deleted'].replace('|','/')}|{row['reason']}|\n"
(ROOT.parent/'正文删冗记录.md').write_text(report,encoding='utf-8')
if '--before-build' not in __import__('sys').argv:
    old=ROOT.parent/'支撑包解压验收_7cdb4vy5/C题修订工程/docs/论文/C题论文_修订稿.md'
    new=ROOT/'docs/论文/C题论文_修订稿.md'
    a=old.read_text(encoding='utf-8');b=new.read_text(encoding='utf-8')
    abody=a.split('## 8 参考文献与AI辅助说明')[0];bbody=b.split('## 8 参考文献与AI辅助说明')[0]
    tables=lambda s:[x.strip() for x in s.splitlines() if x.lstrip().startswith('|')]
    maths=lambda s:re.findall(r'\$\$[\s\S]*?\$\$|\\\[[\s\S]*?\\\]|\\\([\s\S]*?\\\)|(?<!\$)\$(?!\$)[^\n$]+\$',s)
    checks={'table_rows_unchanged':tables(abody)==tables(bbody),'formulas_unchanged':maths(abody)==maths(bbody),
            'disclosure_references_and_source_appendix_unchanged':a.split('## 8 参考文献与AI辅助说明')[1]==b.split('## 8 参考文献与AI辅助说明')[1],
            'deleted_units':len(d['entries']),'body_characters_before':len(abody),'body_characters_after':len(bbody),
            'new_experiment':False}
    assert checks['table_rows_unchanged'] and checks['formulas_unchanged'] and checks['disclosure_references_and_source_appendix_unchanged'],checks
    (dest/'consistency.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(checks,ensure_ascii=False,indent=2))
