from pathlib import Path,PurePosixPath
import json,hashlib,subprocess,sys,tempfile,zipfile
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT.parent
DEST=Path(tempfile.mkdtemp(prefix='支撑包解压验收_',dir=BASE))
with zipfile.ZipFile(BASE/'交付/C题_支撑材料_修订稿.zip') as z:
    for m in z.infolist():
        p=PurePosixPath(m.filename)
        if p.is_absolute() or '..' in p.parts:raise RuntimeError('Unsafe path')
        target=(DEST/Path(*p.parts)).resolve()
        if not target.is_relative_to(DEST.resolve()):raise RuntimeError('Escaped root')
        target.parent.mkdir(parents=True,exist_ok=True)
        if not m.is_dir():target.write_bytes(z.read(m))
work=DEST/'C题修订工程'
results=[]
commands=[['reproduce.py','verify'],['reproduce.py','prepare','--official-data',str(ROOT)],['scripts/build_review_revision.py']]
for args in commands:
    r=subprocess.run([sys.executable,'-X','utf8',*args],cwd=work,capture_output=True,text=True,encoding='utf-8',errors='replace')
    results.append({'args':args,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
    print(' '.join(args),r.returncode,flush=True)
    if r.returncode:break
(BASE/'支撑包验收记录.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
assert len(results)==3 and all(r['returncode']==0 for r in results)
