from pathlib import Path
import hashlib,json,re,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
import pymupdf
from PIL import Image,ImageDraw
out=ROOT/'records/revision_20261019/visual'
out.mkdir(parents=True,exist_ok=True)
pdf=ROOT/'交付材料/修订稿/C题论文_修订稿.pdf'
with pymupdf.open(pdf) as doc:
    texts=[p.get_text() for p in doc]
    hits={term:[i+1 for i,t in enumerate(texts) if term in t] for term in ['相同24','最终采用模型','AI工具使用声明','附录B','13.021','10.952','0.002']}
    for start in range(0,len(doc),6):
        sheet=Image.new('RGB',(900,1305),'#dddddd');d=ImageDraw.Draw(sheet)
        for offset in range(min(6,len(doc)-start)):
            p=doc[start+offset];pix=p.get_pixmap(matrix=pymupdf.Matrix(.48,.48),alpha=False)
            im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples)
            x=(offset%3)*300+(300-im.width)//2;y=(offset//3)*652
            sheet.paste(im,(x,y));d.text((x+5,y+im.height+5),'Page '+str(start+offset+1),fill='black')
        sheet.save(out/f'contact_{start+1:02d}.png')
    key={1,2,3,len(doc)}
    for term in ['相同24','最终采用模型','AI工具使用声明','附录B']:
        key.update(hits[term][:2])
    for n in sorted(key):doc[n-1].get_pixmap(matrix=pymupdf.Matrix(1.3,1.3),alpha=False).save(out/f'p{n:02d}.png')
    assert '目录' in texts[1] and '问题重述' in texts[2]
    assert all(hits[k] for k in ['13.021','10.952','0.002'])
    tables=re.findall(r'表(\d+)\s+[^\n]+','\n'.join(texts[:21]))
    result={'pages':len(doc),'sha256':hashlib.sha256(pdf.read_bytes()).hexdigest(),'key_pages':hits,'table_mentions':tables,
            'visual_review':'pending','source_appendix_starts_on_page':next((n for n in hits['附录B'] if n>2),None)}
(out.parent/'artifact_checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
