"""2026-10-19修订实际核查。AI辅助；不代表队员独立核验。"""
from pathlib import Path
import dataclasses, hashlib, json, sys, time
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
import numpy as np
import pandas as pd
from bev.control import Rule,simulate_rule,compare_thermal_accounting,control_protocol
from bev.durability import run_journey,compare_checkpoint
from bev.io import read_json
from bev.calibration import prepare_trip
from bev.extension import rc_forward

DEST=ROOT/'records/revision_20261019'
DEST.mkdir(parents=True,exist_ok=True)
base=read_json(ROOT/'configs/calibrated.json')
cfg=control_protocol()
baseline=Rule(**cfg['baseline'])
selected=Rule(**read_json(ROOT/'configs/optimized_rule.json'))
same_target=dataclasses.replace(selected,cabin_economy_offset_c=0.)
protocol={'scope':'Retrospective additional check, not a new independent test set. Same fixed parameters/initial state/cycle/constraints; selected hardware settings retained; only cabin economy offset set to zero. No new optimization.',
          'temperatures_c':[25.,40.,-10.], 'baseline_rule':dataclasses.asdict(baseline),'same_target_rule':dataclasses.asdict(same_target),
          'selected_rule':dataclasses.asdict(selected),'step_s':.5,'long_repetitions':3,'parking_checkpoints_s':[3600.,7200.],
          'source_hashes':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ['src/bev/model.py','src/bev/control.py','src/bev/durability.py','configs/calibrated.json','configs/control_protocol.json','configs/optimized_rule.json']}}
(DEST/'protocol.json').write_text(json.dumps(protocol,ensure_ascii=False,indent=2),encoding='utf-8')
result={'protocol':protocol,'same_target':[],'long_recomputed':[],'rc_forward':[],'trajectory_accounting':[]}
# Reintegrate received CSVs; this is a check of stored traces, not a rerun.
for p in sorted((ROOT/'results/timeseries').glob('*.csv')):
    df=pd.read_csv(p)
    item={'file':p.name,'rows':len(df),'columns':len(df.columns),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
    if {'battery_w','dt_s'}<=set(df.columns):item['net_energy_kwh']=float(np.sum(df.battery_w*df.dt_s)/3.6e6)
    result['trajectory_accounting'].append(item)
for ambient in protocol['temperatures_c']:
    runs={}
    for name,rule in [('baseline',baseline),('same_target',same_target),('selected',selected)]:
        trace,metrics=simulate_rule(base,rule,ambient,step_s=.5)
        runs[name]=metrics
        if name=='same_target':trace.to_csv(DEST/f'same_target_{ambient:g}C.csv',index=False,encoding='utf-8-sig')
    result['same_target'].append({'ambient_c':ambient,'metrics':runs,
       'same_target_accounting':compare_thermal_accounting(base,runs['baseline'],runs['same_target']),
       'selected_accounting':compare_thermal_accounting(base,runs['baseline'],runs['selected'])})
    print('Single-cycle three strategies:',ambient,flush=True)
    journeys={}
    for name,rule in [('baseline',baseline),('selected',selected)]:
        journey,trace=run_journey(base,rule,ambient,3,step_s=.5,parking_checkpoints=[3600.,7200.])
        journeys[name]=journey
    a,b=journeys['baseline']['outcomes'][-1],journeys['selected']['outcomes'][-1]
    result['long_recomputed'].append({'ambient_c':ambient,'journeys':journeys,'comparison':compare_checkpoint(base,a,b)})
    print('Fresh 90-minute drive + 2h parking pair:',ambient,flush=True)
rc_parameters=read_json(ROOT/'records/experiments/extension_v1/rc_parameters.json')
for trip in [588,600]:
    trace,out,pred=rc_forward(prepare_trip(trip),rc_parameters,.5)
    result['rc_forward'].append({'trip':trip,'out':out,'prediction':pred})
    print('RC frozen-parameter forward:',trip,flush=True)
def convert(v):
    if isinstance(v,np.generic):return v.item()
    if isinstance(v,np.ndarray):return v.tolist()
    if isinstance(v,pd.DataFrame):return {'rows':len(v),'note':'DataFrame not embedded'}
    raise TypeError(type(v).__name__)
(DEST/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,default=convert,allow_nan=False),encoding='utf-8')
print(json.dumps({'same_target':[{ 'temperature':r['ambient_c'],'saving_pct':r['same_target_accounting']['heat_corrected_saving_pct'],'feasible':r['metrics']['same_target']['feasible']} for r in result['same_target']],
 'long':[{ 'temperature':r['ambient_c'],'saving_pct':r['comparison'].get('raw_saving_pct')} for r in result['long_recomputed']]},ensure_ascii=False,indent=2))
